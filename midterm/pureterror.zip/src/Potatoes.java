public class Potatoes extends Crop{
    String favoredWeather, favoredSeason, unfavorableWeather, unfavorableSeason;

    public Potatoes() {
        name = "Potatoes";
        growthRate = 0.2;
        growthMax = 4;
        health = 40;
        sellingPrice = 20;

        favoredWeather = "Sunny";
        favoredSeason = "Summer";
        unfavorableWeather = "Snowy";
        unfavorableSeason = "Winter";


    }
}