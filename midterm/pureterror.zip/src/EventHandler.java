public class EventHandler{
    Weather wthr = new Weather();
    Carrot crt = new Carrot();
    Cabbage cbg = new Cabbage();
    Potatoes potatoes = new Potatoes();
    Land

    public void seasonDet() {
        if (wthr.currentSeason())
    }

}
