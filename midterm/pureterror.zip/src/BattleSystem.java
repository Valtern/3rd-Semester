import java.util.*;

public class BattleSystem {
    LinkedList<Object> arena = new LinkedList<>();
    Random rand = new Random();
    int turns;
    Player player;
    Enemies enemy;

    public BattleSystem(Player player) {
        this.player = player;
        arena.add(player);
        System.out.println("Battle initiated!");
    }

    public void setEnemy(Enemies enemy) {
        this.enemy = enemy;
        arena.add(enemy);
    }

    public void startBattle() {
        while (player.death() && enemy.isAlive()) {
            turns++;
            System.out.println("\nTurn " + turns);
            if (turns % 2 == 1) {
                System.out.println("Player's turn!");
                playerTurn();
            } else {
                System.out.println("Enemy's turn!");
                enemyTurn();
            }
            System.out.println(player.name + " health: " + player.health);
            System.out.println(enemy.name + " health: " + enemy.hp);
        }

        if (!player.death()) {
            System.out.println(enemy.name + " wins!");
        } else {
            System.out.println(player.name + " wins!");
        }
    }

    public void playerTurn() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose an action:");
        System.out.println("1. Attack");
        System.out.println("2. Items)");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.println("Choose a weapon:");
                int i = 1;
                for (Weapon weapon : player.weapon) {
                    System.out.println(i + ". " + weapon.name + " (Damage: " + weapon.damage + ")");
                    i++;
                }
                int weaponChoice = scanner.nextInt();
                scanner.nextLine();
                if (weaponChoice > 0 && weaponChoice <= player.weapon.size()) {
                    Weapon chosenWeapon = (Weapon) player.weapon.toArray()[weaponChoice - 1];
                    enemy.hp -= chosenWeapon.damage;
                    System.out.println(player.name + " attacks " + enemy.name + " with " + chosenWeapon.name + " for " + chosenWeapon.damage + " damage!");
                } else {
                    System.out.println("Invalid weapon choice.");
                }
                break;
            case 2:
                System.out.println("Item usage is not yet implemented.");
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private void enemyTurn() {
        if (enemy instanceof Pest) {
            ((Pest) enemy).performAction(player);
        } else {
            System.out.println(enemy.name + " attacks " + player.name + " for " + enemy.att + " damage!");
            player.health -= enemy.att;
        }
    }

}