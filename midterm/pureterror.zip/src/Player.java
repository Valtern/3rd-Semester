
import java.util.HashSet;
import java.util.LinkedList;

public class Player {
    String name;
    int money, energy = 100;
    double health = 30;
    Weapon stick = new Weapon("Wooden stick", 4);
    LinkedList<String> inv = new LinkedList<>();
    HashSet<Weapon> weapon = new HashSet<>();
    public void PlayerSetName(String name) {
        System.out.println("Enter your username");
        this.name = name;
        inv.addFirst("Carrots");
        weapon.add(stick);
    }

    public boolean death () {
        if (health <= 0) {
            System.out.println(name + " is dead");
            return false;
        } else {
            return true;
        }
    }


}
