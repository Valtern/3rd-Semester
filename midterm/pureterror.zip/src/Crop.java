public class Crop {
    String name;
    int health;
    double growthRate;
    double growthMax;
    int sellingPrice;

    public Crop() {

    }
}


