public class Weapon {

    public String name;
    public int damage;

    Weapon(String name, int damage) {
        this.name = name;
        this.damage = damage;
    }
}
