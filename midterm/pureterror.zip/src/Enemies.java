public class Enemies {
    String name;
    int hp;
    int def;
    int att;

    Enemies(String name, int hp, int def, int att) {
        this.name = name;
        this.hp = hp;
        this.def = def;
        this.att = att;
    }
    public boolean isAlive() {
        return hp > 0;
    }



}
