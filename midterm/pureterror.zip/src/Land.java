import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class Land {

    char[][] grid;
    LinkedList<Objects> plants = new LinkedList<>();
    Player plyr = new Player();
    Scanner sc = new Scanner(System.in);

    public Land(int rows, int cols) {
        grid = new char[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                grid[i][j] = '0';
            }
        }
    }

    public void displayGrid() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                System.out.print(grid[i][j]);
            }
            System.out.println();
        }
    }

    public void plant(int row, int col) {
        System.out.println("What seed would you like to plant ?");
        System.out.println(plyr.inv.toString());
        int select = sc.nextInt();

        if (!(select == -1)) {
            if (row >= 0 && row < grid.length && col >= 0 && col < grid[0].length) {
                if (grid[row][col] == 'O') {
                    grid[row][col] = 'P';
                    plants.add(plyr.inv.get(select-1));
                } else {
                    System.out.println("Cannot plant here. Spot is unavailable.");

                }
            } else {
                System.out.println("Invalid coordinates.");

            }
        } else {
            System.out.println("Exited !");
        }
    }


}