public class Carrot extends Crop{
    String favoredWeather, favoredSeason, unfavorableWeather, unfavorableSeason;

    public Carrot() {
        name = "Carrot";
        growthRate = 0.2;
        growthMax = 4;
        health = 20;
        sellingPrice = 10;

        favoredWeather = "Sunny";
        favoredSeason = "Spring";
        unfavorableWeather = "Snowy";
        unfavorableSeason = "Winter";


    }
}