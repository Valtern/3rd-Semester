public class Time {
    int days;
    int weeks;
    int month;

    public void timeChange() {
        days++;
        if (days % 7 == 0) {
            weeks++;
            if (weeks % 4 == 0) {
                month++;
            }
        }
    }
}
