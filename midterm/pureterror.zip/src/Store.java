import java.util.*;
public class Store {
    Player plyr = new Player();
    int price;
    String itemName;
    Scanner input = new Scanner(System.in);

    public void shopList(int select) {
        System.out.println("Hello there good sir, what are you looking for ? \n1. Weapons \n2. Crops \b3. Exit");
        int choice = input.nextInt();
        switch (choice) {
            case 1:
                System.out.println("What do you need ? \n1. Wooden sword  \n2. Copper sword \n3. Iron sword \n4. Exit");
                int choice2 = input.nextInt();
                switch (choice2) {
                    case 1:
                        if (checkMoney(plyr.money)) {
                            Weapon woodSwrd = new Weapon("Wooden sword", 6);
                            System.out.println("Bought " + woodSwrd.name);
                            plyr.weapon.add(woodSwrd);
                            break;
                        }
                    case 2:
                        if (checkMoney(plyr.money)) {
                            Weapon coopSwrd = new Weapon("Copper sword", 8);
                            System.out.println("Bought " + coopSwrd.name);
                            plyr.weapon.add(coopSwrd);
                            break;
                        }
                    case 3:
                        if (checkMoney(plyr.money)) {
                            Weapon ironSwrd = new Weapon("Iron sword", 10);
                            System.out.println("Bought " + ironSwrd.name);
                            plyr.weapon.add(ironSwrd);
                            break;
                        }
                }
                break;
            case 2:
                System.out.println("What do you need ? \n1. Carrot seeds \n2. Potatoes seed \n3. Cabbage seed \n4. Exit");
                int choice3 = input.nextInt();
                switch (choice3) {
                    case 1:
                }

        }
    }

    public boolean checkMoney(int money) {
        if (money != price) {
            System.out.println("You don't have enough money");
            return false;
        } else {
            plyr.money = plyr.money - price;
            return true;
        }
    }


}
