public class Cabbage extends Crop{
    String favoredWeather, favoredSeason, unfavorableWeather, unfavorableSeason;

    public Cabbage() {
        name = "Cabbage";
        growthRate = 0.4;
        growthMax = 8;
        health = 30;
        sellingPrice = 50;

        favoredWeather = "Rainy";
        favoredSeason = "Fall";
        unfavorableWeather = "Snowy";
        unfavorableSeason = "Winter";


    }
}